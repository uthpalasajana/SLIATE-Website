<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ATI Gampaha - Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- External CSS -->
    <link rel="stylesheet" href="log.css">
    <link rel="stylesheet" href="../navbar/navbar.css">

</head>
<body>
<div class="sticky-top">
    <?php include "../navbar/navbar1.php"; ?>
</div>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Login Form Design</title>
	<link rel="stylesheet" href="style.css">
</head>
<body>
	<div class="box">
		<h2>Staff Login</h2>
		<form action="">
			<div class="inputBox">
				<input type="text" name="" required="">
				<label for="">Username</label>
			</div>
			<div class="inputBox">
				<input type="password" name="" required="">
				<label for="">Password</label>
			</div>
			<input type="submit" name="" value="Submit"></<br>
            </<br><p class style="color: lightblue;"sign_up></br>Don't have an account? <a href="../login/register.php">Sign up</a></p>
		</form>
	</div>
</body>
</html>
</body>
</html>
