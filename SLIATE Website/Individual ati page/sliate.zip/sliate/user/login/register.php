<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ATI Gampaha - Register</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- External CSS -->
    <link rel="stylesheet" href="log.css">
</head>
<body>

<body>
<div class="sticky-top">
    <?php include "../navbar/navbar1.php"; ?>
</div>
	<div class="box">
		<h2>Staff Registration</h2>
		<form action="">
        <div class="inputBox">
				<input type="text" name="" required="">
				<label for="">Full Name</label>
			</div>
			<div class="inputBox">
				<input type="text" Email="" required="">
				<label for="">Email</label>
			</div>
			<div class="inputBox">
				<input type="password" password="" required="">
				<label for="">Password</label>
			</div>
            <div class="inputBox">
				<input type="password" password="" required="">
				<label for="">Confirm Password</label>
			</div>
			<input type="submit" name="" value="Submit">
		</form>
	</div>
</body>
</html>
